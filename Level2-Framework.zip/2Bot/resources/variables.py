from datetime import datetime

TODAY = datetime.now()
